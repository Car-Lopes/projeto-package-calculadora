# projeto-package-calculadora

Description. 
The package calculadora is used to:
	Operacao:
        - Operadores
	Calculo:
        - A logica 
    Calculadora:
        - Entradas 

## Installation

Use the package manager [pip](https://pip.pypa.io/en/stable/) to install package_name

```bash
pip install calc_simple_calculation
```

## Usage

```python
from calc_simple_calculation import operacao
operacao.operacao()
```

## Author
Carlos Lopes

## License
[MIT](https://choosealicense.com/licenses/mit/)