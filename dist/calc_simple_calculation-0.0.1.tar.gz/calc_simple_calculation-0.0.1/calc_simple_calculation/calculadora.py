import operacao 
import calculo

repetir = 1

while repetir != 0 :  
    
    a = int(input('Digite um numero: ')) 
    b = int(input('Digite outro numero: ')) 
    saida = calculo.calcular(a,b)

    repetir = int(input('Digite entre (1 e 0) - 1 para continuar e 0 para encerrar: '))  
    

    

    